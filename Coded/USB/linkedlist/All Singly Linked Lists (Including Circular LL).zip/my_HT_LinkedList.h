#include "LinkedList.h"

template <class T>
class My_HT_LinkedList: public LinkedList<T>
{
public:
	void insertSorted(T);
	void insertAtTail(T);
	void insertAtHead(T);
	T deleteFromHead();
	T deleteFromTail();
	bool deleteValue(T);
	bool searchValue(T);
	void display();
};

template <class T>
void My_HT_LinkedList<T>::insertAtHead(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
		newNode = nullptr;
	}
	else
	{
		newNode->next = head;
		head = newNode;
		newNode = nullptr;
	}
}

template <class T>
void My_HT_LinkedList<T>::insertAtTail(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
		newNode = nullptr;
	}
	else
	{
		tail->next = newNode;
		tail = tail->next;
		newNode = nullptr;
	}
}

template <class T>
void My_HT_LinkedList<T>::insertSorted(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
		newNode = nullptr;
	}
	else if (value < head->data)
	{
		newNode->next = head;
		head = newNode;
		newNode = nullptr;
	}
	else if (value > tail->data)
	{
		tail->next = newNode;
		tail = tail->next;
		newNode = nullptr;
	}
	else
	{
		Node<T>* trail = head;
		while (trail->next != nullptr)
		{
			if (value < trail->next->data)
			{
				newNode->next = trail->next;
				trail->next = newNode;
				newNode = nullptr;
				break;
			}
			trail = trail->next;
		}
	}
}

template <class T>
T My_HT_LinkedList<T>::deleteFromHead()
{
	if (head == nullptr && tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (head == tail)
	{
		T returningValue = head->data;
		delete head;
		head = nullptr;
		tail = nullptr;
		return returningValue;
	}
	else
	{
		T returningValue = head->data;
		Node<T>* temp = head;
		head = head->next;
		delete temp;
		temp = nullptr;
		return returningValue;
	}
	return NULL;
}

template <class T>
T My_HT_LinkedList<T>::deleteFromTail()
{
	if (head == nullptr && tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (head == tail)
	{
		T returningValue = tail->data;
		delete tail;
		head = nullptr;
		tail = nullptr;
		return returningValue;
	}
	else
	{
		Node<T>* trail = head;
		while (trail->next != tail)
			trail = trail->next;
		T returningValue = trail->next->data;
		delete trail->next;
		tail = trail;
		tail->next = nullptr;
		trail = nullptr;
		return returningValue;
	}
	return NULL;
}

template <class T>
bool My_HT_LinkedList<T>::deleteValue(T value)
{
	if (head == nullptr && tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (value == head->data)
	{
		Node<T>* temp = head;
		head = head->next;
		delete temp;
		temp = nullptr;
		return true;
	}
	else if (value == tail->data)
	{
		Node<T>* trail = head;
		while (trail->next != tail)
			trail = trail->next;
		delete trail->next;
		tail = trail;
		tail->next = nullptr;
		trail = nullptr;
		return true;
	}
	else
	{
		Node<T>* trail = head;
		while (true)
		{
			if (value == trail->next->data)
				break;
			trail = trail->next;
			if (trail->next == tail)
				return false;
		}
		Node<T>* temp = trail->next;
		trail->next = trail->next->next;
		delete temp;
		temp = nullptr;
		return true;
	}
	return false;
}

template <class T>
bool My_HT_LinkedList<T>::searchValue(T value)
{
	if (head == nullptr && tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		Node<T>* trail = head;
		while (true)
		{
			if (value == trail->data)
				return true;
			trail = trail->next;
			if (trail == nullptr)
				break;
		}
	}
	return false;
}

template <class T>
void My_HT_LinkedList<T>::display()
{
	if (head == nullptr && tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		Node<T>* trail = head;
		cout << "Linked List: " << endl;
		while (trail != nullptr)
		{
			cout << trail->data << "->";
			trail = trail->next;
		}
		cout << "nullptr" <<endl;
	}
}