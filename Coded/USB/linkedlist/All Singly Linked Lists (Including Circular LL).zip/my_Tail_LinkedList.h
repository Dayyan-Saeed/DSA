#include "LinkedList.h"

template <class T>
class My_Tail_LinkedList: public LinkedList<T>
{
public:
	void insertSorted(T);
	void insertAtTail(T);
	void insertAtHead(T);
	T deleteFromHead();
	T deleteFromTail();
	bool deleteValue(T);
	bool searchValue(T);
	void display();
};

template <class T>
void My_Tail_LinkedList<T>::insertAtHead(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;

	if (tail == nullptr)
	{
		tail = newNode;
		tail->next = tail;
		newNode = nullptr;
	}
	else
	{
		newNode->next = tail->next;
		tail->next = newNode;
		newNode = nullptr;
	}
}

template <class T>
void My_Tail_LinkedList<T>::insertAtTail(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	
	if (tail == nullptr)
	{
		tail = newNode;
		tail->next = tail;
		newNode = nullptr;
	}
	else
	{
		newNode->next = tail->next;
		tail->next = newNode;
		tail = tail->next;
		newNode = nullptr;
	}
}

template <class T>
void My_Tail_LinkedList<T>::insertSorted(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	
	if (tail == nullptr)
	{
		tail = newNode;
		tail->next = tail;
		newNode = nullptr;
	}
	else if (value >= tail->data)
	{
		newNode->next = tail->next;
		tail->next = newNode;
		tail = tail->next;
		newNode = nullptr;
	}
	else if (value <= tail->next->data)
	{
		newNode->next = tail->next;
		tail->next = newNode;
		newNode = nullptr;
	}
	else
	{
		Node<T>* trail = tail->next;
		while (true)
		{
			if (value <= trail->next->data)
			{
				newNode->next = trail->next;
				trail->next = newNode;
				newNode = nullptr;
				break;
			}
			trail = trail->next;
			if (trail == tail)
				break;
		}
	}
}

template <class T>
T My_Tail_LinkedList<T>::deleteFromHead()
{
	if (tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (tail->next == tail)
	{
		T returningValue = tail->data;
		delete tail;
		tail = nullptr;
		return returningValue;
	}
	else
	{
		T returningValue = tail->next->data;
		Node<T>* temp = tail->next;
		tail->next = tail->next->next;
		delete temp;
		return returningValue;
	}
	return NULL;
}

template <class T>
T My_Tail_LinkedList<T>::deleteFromTail()
{
	if (tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (tail->next == tail)
	{
		T returningValue = tail->data;
		delete tail;
		tail = nullptr;
		return returningValue;
	}
	else
	{
		T returningValue = tail->data;
		Node<T>* temp = tail->next;
		Node<T>* trail = tail->next;
		while (trail->next != tail)
			trail = trail->next;
		tail = trail;
		delete tail->next;
		tail->next = temp;
		temp = nullptr;
		trail = nullptr;
		return returningValue;
	}
	return NULL;
}

template <class T>
bool My_Tail_LinkedList<T>::deleteValue(T value)
{
	if (tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (value == tail->data && tail->next == tail)
	{
		delete tail;
		tail = nullptr;
		return true;
	}
	else if (value == tail->data && tail->next != tail)
	{
		Node<T>* trail = tail->next;
		Node<T>* temp = tail->next;
		while (trail->next != tail)
			trail = trail->next;
		tail = trail;
		delete tail->next;
		tail->next = temp;
		temp = nullptr;
		trail = nullptr;
		return true;
		
	}
	else if (value == tail->next->data)
	{
		Node<T>* temp = tail->next;
		tail->next = tail->next->next;
		delete temp;
		temp = nullptr;
		return true;
	}
	else
	{
		Node<T>* trail = tail->next;
		while (true)
		{
			if (value == trail->next->data)
			{
				Node<T>* temp = trail->next;
				trail->next = trail->next->next;
				delete temp;
				temp = nullptr;
				trail = nullptr;
				return true;
			}
			trail = trail->next;
			if (trail->next == tail)
				break;
		}
	}
	return false;
}

template <class T>
bool My_Tail_LinkedList<T>::searchValue(T value)
{
	if (tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		Node<T>* trail = tail;
		while (true)
		{
			if (value == trail->data)
				return true;
			trail = trail->next;
			if (trail == tail)
				break;
		}
	}
	return false;
}

template <class T>
void My_Tail_LinkedList<T>::display()
{
	if (tail == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		cout << "Linked List: " << endl;
		Node<T>* trail = tail->next;
		while (true)
		{
			cout << trail->data;
			trail = trail->next;
			if (trail == tail->next)
				break;
			cout << "->";
		}
		cout << endl;
	}
}