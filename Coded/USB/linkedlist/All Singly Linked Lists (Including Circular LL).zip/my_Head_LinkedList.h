#include "LinkedList.h"

template <class T>
class My_Head_LinkedList : public LinkedList<T>
{
public:
	void insertSorted(T);
	void insertAtTail(T);
	void insertAtHead(T);
	T deleteFromHead();
	T deleteFromTail();
	bool deleteValue(T);
	bool searchValue(T);
	void display();
};

template <class T>
void My_Head_LinkedList<T>::insertAtHead(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr)
	{
		head = newNode;
		newNode = nullptr;
	}
	else
	{
		newNode->next = head;
		head = newNode;
		newNode = nullptr;
	}

}

template <class T>
void My_Head_LinkedList<T>::insertAtTail(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr)
	{
		head = newNode;
		newNode = nullptr;
	}
	else
	{
		Node<T>* trail = head;
		while (trail->next != nullptr)
			trail = trail->next;
		trail->next = newNode;
		newNode = nullptr;
	}

}

template <class T>
void My_Head_LinkedList<T>::insertSorted(T value)
{
	Node<T>* newNode = new Node<T>;
	newNode->data = value;
	newNode->next = nullptr;
	if (head == nullptr)
	{
		head = newNode;
		newNode = nullptr;
	}
	else if (value <= head->data)
	{
		newNode->next = head;
		head = newNode;
		newNode = nullptr;
	}
	else
	{
		Node<T>* trail = head;
		bool found = false;
		while (trail->next != nullptr)
		{
			if (value <= trail->next->data)
			{
				newNode->next = trail->next;
				trail->next = newNode;
				found = true;
				break;
			}
			trail = trail->next;		
		}
		if (found == false)
			trail->next = newNode;
	}
}

template <class T>
T My_Head_LinkedList<T>::deleteFromHead()
{
	if (head == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		T returningValue = head->data;
		head = head->next;
		return returningValue;
	}
	return NULL;
}

template <class T>
T My_Head_LinkedList<T>::deleteFromTail()
{
	if (head == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (head->next == nullptr)
	{
		T returningValue = head->data;
		delete head;
		head = nullptr;
		return returningValue;
	}
	else
	{
		Node<T>* trail = head;
		while (trail->next->next != nullptr)
			trail = trail->next;
		T returningValue = trail->next->data;
		delete trail->next;
		trail->next = nullptr;
		trail = nullptr;
		return returningValue;
	}
	return NULL;
}

template <class T>
bool My_Head_LinkedList<T>::deleteValue(T value)
{
	if (head == nullptr)
		cout << "Linked List is Empty." << endl;
	else if (value == head->data)
	{
		Node<T>* temp = head;
		head = head->next;
		delete temp;
		temp = nullptr;
		return true;
	}
	else
	{
		Node<T>* trail = head;
		while (trail->next != nullptr)
		{
			if (value == trail->next->data)
			{
				Node<T>* temp = trail->next;
				trail->next = trail->next->next;
				delete temp;
				temp = nullptr;
				return true;
			}
			trail = trail->next;
		}
	}
	return false;
}

template <class T>
bool My_Head_LinkedList<T>::searchValue(T value)
{
	if (head == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		Node<T>* trail = head;
		while (trail != nullptr)
		{
			if (value == trail->data)
				return true;
			trail = trail->next;
		}
	}
	return false;
}

template <class T>
void My_Head_LinkedList<T>::display()
{
	if (head == nullptr)
		cout << "Linked List is Empty." << endl;
	else
	{
		cout << "Linked List: " << endl;
		Node<T>* trail = head;
		while (trail != nullptr)
		{
			cout << trail->data << "->";
			trail = trail->next;
		}
		cout << "nullptr" << endl;
	}
}