#include "my_HT_LinkedList.h"
#include "my_Head_LinkedList.h"
#include "my_Tail_LinkedList.h"

int main()
{
	My_HT_LinkedList<int> ht;
	//ht.insertSorted(1);
	//ht.insertSorted(3);
	//ht.insertSorted(5);
	//ht.insertSorted(2);
	//ht.insertSorted(4);
	//ht.display();


	//cout << "\n\n";
	//ht.deleteValue(6);
	//cout << "Value Found: " << ht.searchValue(13) << endl;
	//ht.display();

	My_Head_LinkedList<int> h;
	//h.insertAtHead(5);
	//h.insertSorted(8);
	//h.insertSorted(10);
	//h.insertSorted(11);
	//h.insertSorted(12);
	//h.insertSorted(7);
	//h.display();

	//cout << "\n\n";
	//cout << "Value Found: " << h.searchValue(13) << endl;
	//h.deleteFromHead();
	//h.deleteFromTail();
	//h.deleteValue(7);
	//h.display();

	My_Tail_LinkedList<int> t;
	t.insertSorted(5);
	t.insertSorted(19);
	t.insertSorted(1);
	t.insertSorted(2);
	t.insertSorted(6);
	t.insertSorted(10);
	t.display();

	cout << "\n\n";
	cout << "Value Found: " << t.searchValue(19) << endl;
	t.deleteValue(19);
	t.deleteFromHead();
	t.deleteFromTail();
	t.deleteValue(2);
	t.display();

	system("pause");
	return 0;
}