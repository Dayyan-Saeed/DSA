#pragma once
#include "Tree.h"
class BST :public Tree
{
	void INORDER(Node* p);
	void PREORDER(Node* p);
	void POSTORDER(Node* p);
	void TOTALNODES(Node* p, int& count);
	
public:
	void insert(int);
	void inorder();
	void preorder();
	void postorder();
	int totalNodes();
	bool deleteValue(int);
	int findSmallest();
	int findLargest();
};

int BST::findLargest()
{
	if (root != nullptr)
	{
		Node* p = root;
		while (p != nullptr)
		{
			if (p->rightChild == nullptr)
				return p->data;
			else
				p = p->rightChild;
		}
	}
	else
	{
		cout << "Tree is empty" << endl;
		return NULL;
	}

}


int BST::findSmallest()
{
	if (root != nullptr)
	{
		Node* p = root;
		while (p != nullptr)
		{
			if (p->leftChild == nullptr)
				return p->data;
			else
				p = p->leftChild;
		}
	}
	else
	{
		cout << "Tree is empty" << endl;
		return NULL;
	}
	
}
bool BST::deleteValue(int v)
{
	if (root == nullptr)	//empty tree
	{
		cout << "Tree is empty" << endl;
		return false;
	}

	else //non-empty tree
	{
		Node* p = root;
		Node* c = root;

		while (1)
		{

			if (v == c->data)	//actual deletion is done here
			{
				if (c->leftChild != nullptr && c->rightChild != nullptr) //2 children case
				{
					Node* t = c;
					p = t;
					
					//c = c->leftChild;

					//while (c->rightChild != nullptr)
					//{
					//	p = c;
					//	c = c->rightChild;
					//}

					c = c->rightChild;

					while (c->leftChild != nullptr)
					{
						p = c;
						c = c->leftChild;
					}

					v = c->data;
					t->data = v;

				}

				if (c->leftChild == nullptr && c->rightChild == nullptr) //leaf node case
				{
					delete c;
					c = nullptr;

					if (v < p->data) //left child was deleted
						p->leftChild = nullptr;

					else //right was deleted;
						p->rightChild = nullptr;

					return true;
				}

				else if (c->leftChild != nullptr && c->rightChild == nullptr) //single child, where left exists
				{
					if (v < p->data)	//leftchild of parent
						p->leftChild = c->leftChild;

					else //right child of parent
						p->rightChild = c->leftChild;

					delete c;
					c = nullptr;
					return true;
				}

				else if (c->leftChild == nullptr && c->rightChild != nullptr) //single child, where right exists
				{
					if (v < p->data)	//leftchild of parent
						p->leftChild = c->rightChild;

					else //right child of parent
						p->rightChild = c->rightChild;

					delete c;
					c = nullptr;
					return true;
				}
			
			}

			if (v < c->data)
			{
				p = c;
				c = c->leftChild;

			}

			else
			{
				p = c;
				c = c->rightChild;
			}
		}
	}
}
void BST::TOTALNODES(Node* p, int& count) //at the start, this node should be ROOT
{
	if (p != nullptr)
	{
		TOTALNODES(p->leftChild, count);
		count++;
		TOTALNODES(p->rightChild, count);
	}
}

int BST::totalNodes()
{
	int c = 0;
	if (root != nullptr)
		TOTALNODES(root, c);

	else
		cout << "Tree is EMPTY" << endl;

	return c;
}

void BST::postorder()
{
	if (root != nullptr)
		POSTORDER(root);

	else
		cout << "Tree is EMPTY" << endl;
}


void BST::preorder()
{
	if (root != nullptr)
		PREORDER(root);

	else
		cout << "Tree is EMPTY" << endl;
}

void BST::inorder()
{
	if (root != nullptr)
		INORDER(root);

	else
		cout << "Tree is EMPTY" << endl;
}

void BST::INORDER(Node* p) //at the start, this node should be ROOT
{
	if (p != nullptr)
	{
		INORDER(p->leftChild);
		cout << p->data << " ";
		INORDER(p->rightChild);
	}
}

void BST::PREORDER(Node* p) //at the start, this node should be ROOT
{
	if (p != nullptr)
	{
		cout << p->data << " ";
		PREORDER(p->leftChild);
		PREORDER(p->rightChild);
	}
}

void BST::POSTORDER(Node* p) //at the start, this node should be ROOT
{
	if (p != nullptr)
	{
		POSTORDER(p->leftChild);
		POSTORDER(p->rightChild);
		cout << p->data << " ";
	}
}

void BST::insert(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->leftChild = nullptr;
	nn->rightChild = nullptr;

	if (root == nullptr)
		root = nn;

	else
	{
		Node* p = root;
		while (1)
		{
			if (value < p->data) //left side
			{
				if (p->leftChild == nullptr)
				{
					p->leftChild = nn;
					break;
				}

				else
				{
					p = p->leftChild;
				}
			}

			else //right side
			{
				if (p->rightChild == nullptr)
				{
					p->rightChild = nn;
					break;
				}

				else
				{
					p = p->rightChild;
				}
			}
		}
	}
}
