#include "BST.h"

int main()
{
	BST bst;

	bst.insert(200);
	bst.insert(160);
	bst.insert(190);
	bst.insert(170);
	bst.insert(100);
	bst.insert(195);
	bst.insert(197);
	bst.insert(72);
	bst.insert(159);
	bst.insert(159);
	bst.insert(130);
	bst.insert(235);
	bst.insert(220);
	bst.insert(218);
	bst.insert(240);
	bst.insert(260);
	bst.insert(238);
	

	bst.deleteValue(160);

	bst.inorder();
	
	return 0;
}