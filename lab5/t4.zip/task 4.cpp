#include <iostream>
#include <stack>
using namespace std;

struct Node {
    char data;
    Node* next;
};

bool isPalindrome(Node* head) {
    stack<char> s;
    Node* current = head;
    while (current != nullptr) {
        s.push(current->data);
        current = current->next;
    }
    current = head;
    while (current != nullptr) {
        char top = s.top();
        s.pop();
        if (top != current->data) {
            return false;
        }
        current = current->next;
    }
    return true;
}

int main() {
    Node* head = new Node{ 'C', new Node{'I', new Node{'V', new Node{'I', new Node{'C', nullptr}}}} };

    cout << (isPalindrome(head) ? "Given list is Palindrome" : "Given list is not Palindrome") << endl;

    Node* head2 = new Node{ 'S', new Node{'O', new Node{'O', new Node{'N', nullptr}}} };
    cout << (isPalindrome(head2) ? "Given list is Palindrome" : "Given list is not Palindrome") << endl;

    // Clean up memory
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
    current = head2;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }

    return 0;
}
