#include "node.h"
#include <iostream>

template<typename Type>
class MyCircularList {
private:
    Node<Type>* tail;
    int size;
public:
    MyCircularList();
    ~MyCircularList();
    bool isEmpty();
    int sizeOfList();
    virtual void insertAtFront(Type) = 0;
    virtual void insertAtLast(Type) = 0;
    virtual void removeAtFront(Type) = 0;
    virtual void removeAtLast(Type) = 0;
    virtual void insertAtSpecificPosition(Type, Type) = 0;
    virtual void insertNext(Type Nodevalue, Type) = 0;
    virtual void insertSorted(Type) = 0;
    virtual void sortLinkedList(Type) = 0;
    virtual Type removeFromPosition(Type) = 0;
    virtual Type removeNext() = 0;
    virtual void reverseListNode() = 0;
};

template<typename Type>
MyCircularList<Type>::MyCircularList() : tail(nullptr), size(0) {}

template<typename Type>
MyCircularList<Type>::~MyCircularList() {
    Node<Type>* current = tail->Next;
    while (current != tail) {
        Node<Type>* temp = current;
        current = current->Next;
        delete temp;
    }
    delete tail;
}

template<typename Type>
bool MyCircularList<Type>::isEmpty() {
    return size == 0;
}

template<typename Type>
int MyCircularList<Type>::sizeOfList() {
    return size;
}
