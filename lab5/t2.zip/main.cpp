#include <iostream>
#include "Mylist.h"

int main() {
    MyList<int> myList;

    // Add elements to the list
    myList.insertAtFront(5);
    myList.insertAtFront(10);
    myList.insertAtLast(15);
    myList.insertAtLast(20);

    // Print the list
    myList.printList();

    // Remove elements from the list
    myList.removeAtFront();
    myList.removeAtLast();

    // Print the list after removal
    myList.printList();

    // Insert an element at a specific position
    myList.insertAtSpecificPosition(25, 10);

    // Print the list after insertion
    myList.printList();

    // Insert an element at the next position of a given node
    myList.insertNext(15, 30);

    // Print the list after insertion
    myList.printList();

    // Insert an element in a sorted order
    myList.insertSorted(12);

    // Print the list after insertion
    myList.printList();

    // Sort the list in ascending order
    myList.sortLinkedList();

    // Print the list after sorting
    myList.printList();

    // Reverse the list
    myList.reverseListNode();

    // Print the list after reversal
    myList.printList();

    // Remove and return an element from a specific position
    int removedElement = myList.removeFromPosition(2);
    std::cout << "Removed element: " << removedElement << std::endl;

    // Print the list after removal
    myList.printList();

    // Remove the next element of a given node
    myList.removeNext();

    // Print the list after removal
    myList.printList();

    return 0;
}
