#include "node.h"
#include "list.h"

template <typename Type>
class MyList : public List<Type> {
private:
    Node<Type>* head;

public:
    MyList() : head(nullptr) {}
    ~MyList();

    bool isEmpty();
    int sizeOfList();

    void insertAtFront(Type value);
    void insertAtLast(Type value);
    void removeAtFront(Type& value);
    void removeAtLast(Type& value);
    void insertAtSpecificPosition(Type nodeValue, Type value);
    void insertNext(Type nodeValue, Type value);
    void insertSorted(Type value);
    void sortLinkedList(Type value);
    Type removeFromPosition(Type value);
    Type removeNext();
    void reverseListNode();
};

template <typename Type>
MyList<Type>::~MyList() {
    Node<Type>* current = head;
    while (current != nullptr) {
        Node<Type>* temp = current;
        current = current->Next;
        delete temp;
    }
}

template <typename Type>
bool MyList<Type>::isEmpty() {
    return head == nullptr;
}

template <typename Type>
int MyList<Type>::sizeOfList() {
    int size = 0;
    Node<Type>* current = head;
    while (current != nullptr) {
        size++;
        current = current->Next;
    }
    return size;
}



