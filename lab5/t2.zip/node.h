template <typename Type>
class Node {
public:
    Type Data;
    Node<Type>* Next;

    Node(Type data) : Data(data), Next(nullptr) {}
    ~Node() {}
};


