
template<typename Type>
class List  {

 public:
    virtual void insertAtFront(Type) = 0;
    virtual void insertAtLast(Type) = 0;
    virtual void removeAtFront(Type) = 0;
    virtual void removeAtLast(Type) = 0;
    virtual void insertAtSpecificPosition(Type, Type) = 0;
    virtual void insertNext(Type, Type) = 0;
    virtual void insertSorted(Type) = 0;
    virtual void sortLinkedList(Type) = 0;
    virtual Type removeFromPosition(Type) = 0;
    virtual Type removeNext() = 0;
    virtual void reverseListNode() = 0;
    virtual int getSize() = 0;
    virtual void printList() = 0;

};

