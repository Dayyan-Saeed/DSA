#include <iostream>
#include "list.h"
#include "LinkedList.h"


int main() {
    LinkedList<int> mylist;

    mylist.insertAtFront(5);
    mylist.insertAtFront(3);
    mylist.insertAtLast(8);
    mylist.insertAtLast(10);
    mylist.insertAtSpecificPosition(8, 9);
    mylist.insertAtSpecificPosition(5, 7);
    mylist.insertNext(3, 4);
    mylist.insertSorted(6);
    
    mylist.reverseListNode();
    std::cout << "List size: " << mylist.getSize() << "\n";
    std::cout << "List contents: ";
    mylist.printList();
    std::cout << "\n";
    int value = mylist.removeFromPosition(0);
    std::cout << "Removed value: " << value << "\n";
    std::cout << "List size: " << mylist.getSize() << "\n";
    std::cout << "List contents: ";
    mylist.printList();
    std::cout << "\n";
    value = mylist.removeNext();
    std::cout << "Removed value: " << value << "\n";
    std::cout << "List size: " << mylist.getSize() << "\n";
    std::cout << "List contents: ";
    mylist.printList();
    std::cout << "\n";
    return 0;
}




