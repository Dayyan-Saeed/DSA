#include "list.h"

template<typename Type>
class LinkedList : public List<Type> {
private:
    struct Node {
        Type data;
        Node* next;
    };
    Node* head;
    int size;
public:
    LinkedList() : head(nullptr), size(0) {}
    void insertAtFront(Type);
    void insertAtLast(Type);
    void removeAtFront(Type);
    void removeAtLast(Type);
    void insertAtSpecificPosition(Type, Type);
    void insertNext(Type, Type);
    void insertSorted(Type);
    void sortLinkedList(Type);
    Type removeFromPosition(Type);
    Type removeNext();
    void reverseListNode();
    int getSize();
    void printList();
    ~LinkedList();
};


template<typename Type>
void LinkedList<Type>::insertAtFront(Type value) {
    Node* new_node = new Node;
    new_node->data = value;
    new_node->next = head;
    head = new_node;
    size++;
}

template<typename Type>
void LinkedList<Type>::insertAtLast(Type value) {
    Node* new_node = new Node;
    new_node->data = value;
    new_node->next = nullptr;
    if (head == nullptr) {
        head = new_node;
    }
    else {
        Node* curr = head;
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        curr->next = new_node;
    }
    size++;
}

template<typename Type>
void LinkedList<Type>::removeAtFront(Type) {
    if (head == nullptr) {
        return;
    }
    Node* temp = head;
    head = head->next;
    delete temp;
    size--;
}

template<typename Type>
void LinkedList<Type>::removeAtLast(Type) {
    if (head == nullptr) {
        return;
    }
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
    }
    else {
        Node* curr = head;
        while (curr->next->next != nullptr) {
            curr = curr->next;
        }
        delete curr->next;
        curr->next = nullptr;
    }
    size--;
}

template<typename Type>
void LinkedList<Type>::insertAtSpecificPosition(Type value, Type target) {
    Node* new_node = new Node;
    new_node->data = value;
    if (head == nullptr) {
        head = new_node;
        new_node->next = nullptr;
        size++;
        return;
    }
    if (head->data == target) {
        new_node->next = head;
        head = new_node;
        size++;
        return;
    }
    Node* curr = head;
    while (curr->next != nullptr && curr->next->data != target) {
        curr = curr->next;
    }
    if (curr->next == nullptr) {
        curr->next = new_node;
        new_node->next = nullptr;
        size++;
    }
    else {
        new_node->next = curr->next;
        curr->next = new_node;
        size++;
    }
}
template<typename Type>
void LinkedList<Type>::insertNext(Type node_value, Type value) {
    Node* new_node = new Node;
    new_node->data = value;
    if (head == nullptr) {
        head = new_node;
        new_node->next = nullptr;
        size++;
        return;
    }
    Node* curr = head;
    while (curr->next != nullptr && curr->data != node_value) {
        curr = curr->next;
    }
    if (curr->data != node_value) {
        std::cout << "Error: node value not found in the linked list\n";
    }
    else if (curr->next == nullptr) {
        curr->next = new_node;
        new_node->next = nullptr;
        size++;
    }
    else {
        new_node->next = curr->next;
        curr->next = new_node;
        size++;
    }
}

template<typename Type>
void LinkedList<Type>::insertSorted(Type value) {
    Node* new_node = new Node;
    new_node->data = value;
    if (head == nullptr) {
        head = new_node;
        new_node->next = nullptr;
        size++;
        return;
    }
    if (value < head->data) {
        new_node->next = head;
        head = new_node;
        size++;
        return;
    }
    Node* curr = head;
    while (curr->next != nullptr && curr->next->data < value) {
        curr = curr->next;
    }
    new_node->next = curr->next;
    curr->next = new_node;
    size++;
}

template<typename Type>
void LinkedList<Type>::sortLinkedList(Type) {
    if (head == nullptr) {
        return;
    }
    Node* curr_i = head;
    while (curr_i != nullptr) {
        Node* curr_j = curr_i->next;
        while (curr_j != nullptr) {
            if (curr_i->data > curr_j->data) {
                Type temp = curr_i->data;
                curr_i->data = curr_j->data;
                curr_j->data = temp;
            }
            curr_j = curr_j->next;
        }
        curr_i = curr_i->next;
    }
}

template<typename Type>
Type LinkedList<Type>::removeFromPosition(Type) {
    if (head == nullptr) {
        std::cout << "Error: linked list is empty\n";
        return -1;
    }
    Type value = head->data;
    Node* temp = head;
    head = head->next;
    delete temp;
    size--;
    return value;
}

template<typename Type>
Type LinkedList<Type>::removeNext() {
    if (head == nullptr || head->next == nullptr) {
        std::cout << "Error: linked list has less than two elements\n";
        return -1;
    }
    Type value = head->next->data;
    Node* temp = head->next;
    head->next = head->next->next;
    delete temp;
    size--;
    return value;
}



template<typename Type>
void LinkedList<Type>::reverseListNode() {
    if (head == nullptr || head->next == nullptr) {
        return;
    }
    Node* prev = nullptr;
    Node* curr = head;
    Node* next = nullptr;
    while (curr != nullptr) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
}

template<typename Type>
LinkedList<Type>::~LinkedList() {
    Node* curr = head;
    while (curr != nullptr) {
        Node* temp = curr;
        curr = curr->next;
        delete temp;
    }

}

template<typename Type>
int LinkedList<Type>::getSize() {
    return size;
}

template<typename Type>
void LinkedList<Type>::printList() {
    Node* curr = head;
    while (curr != nullptr) {
        std::cout << curr->data << " ";
        curr = curr->next;
    }
}
