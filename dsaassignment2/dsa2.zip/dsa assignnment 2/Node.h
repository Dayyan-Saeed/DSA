class Node {
public:
	char data;
	Node* next;
};