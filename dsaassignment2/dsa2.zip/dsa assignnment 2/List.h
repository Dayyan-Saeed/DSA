class List
{
public:
	virtual void insert() = 0;
	virtual void rearrange() = 0;
	virtual void print();

	
};